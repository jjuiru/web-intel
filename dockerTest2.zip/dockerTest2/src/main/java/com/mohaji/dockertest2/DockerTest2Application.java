package com.mohaji.dockertest2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerTest2Application {

    public static void main(String[] args) {
        SpringApplication.run(DockerTest2Application.class, args);
    }

}
