package com.mohaji.dockertest2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerTest2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
